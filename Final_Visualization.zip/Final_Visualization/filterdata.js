


var width = 800	,
    height = 400;

var div = d3.select("body").append("div") 
    .attr("class", "tooltip");

var svg = d3.select("body").append("svg")
	.attr("class", "svg")
    .attr("width", width)
    .attr("height", height);

var projection = d3.geo.mercator()
    .center([0, 5 ])
    .scale(100)
    .rotate([0,0]);

var path = d3.geo.path()
    .projection(projection);

var g = svg.append("g")
	.attr("width", width)
    .attr("height", height);

function showtooltip(d) {
    var coord = d3.mouse(this);
    d3  .select(this)
      .style("stroke-width", 2);
    div .transition()
      .duration(100)
      .style("opacity", 1);
    div .html("Name:" + d.names + "<br/>" + "Tweet:" + d.tweet)
      .style("left", coord[0] + 10 + "px")
      .style("top", coord[1] + 10 + "px");
    }

function hidetooltip(d) {
    var coord = d3.mouse(this);
    d3  .select(this)
      .style("stroke-width", 2);
    div .transition()
      .duration(100)
      .style("opacity", 0);
    div .html(d.tweet)
      .style("left", coord[0] + 20 + "px")
      .style("top", coord[1] - 15 + "px");
    }

function displaywordle(){
var minutecount = d3.select('#slider3text').text();			 


var result;

d3.tsv("trend_word.tsv", function(data)
  {
//   console.log(data);

  	for(i=0;i<data.length;i++)
  	{
      
      if(data[i].timeslot == minutecount)
      {	// remove old wordle
      	d3.select('#wordle').remove();

      	console.log("match");
      	console.log(data[i].wordle);
      	result = data[i].wordle;
      	result = result.trim();
      	result = result.split(',');

      	var fill = d3.scale.category20();



  d3.layout.cloud().size([300, 300])
      .words(result.map(function(d) {
        return {text: d, size: 40};
      }))
      .padding(5)
      .rotate(function() { return ~~(Math.random() * 2) * 60; })
      .font("Impact")
      .fontSize(function(d) { return d.size; })
      .on("end", draw)
      .start();

  function draw(words) {
  	console.log("in draw");
    d3.select("body").append("svg")
    	.attr("id","wordle")

        .attr("width", 300)
        .attr("height", 300)
        .append("g")
        

        .attr("transform", "translate(150,150)")
        

      .selectAll("text")
        .data(words)
      .enter().append("text")
        .style("font-size", function(d) { return d.size + "px"; })
        .style("font-family", "Impact")
        .style("scale", "n")
        .style("spiral", "Rectangular")
        .style("fill", function(d, i) { return fill(i); })
        .attr("text-anchor", "middle")
        .attr("transform", function(d) {
          return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
        })
        .text(function(d) { return d.text; });
 	 }
      	return;	
      
      }
    }

  });

console.log(result);





};
function displaydata(){
	//console.log(d3.select('#slider3text').text());

	g.selectAll('circle').remove();

	d3.csv("manu_final.csv", function(error, data) {
	
	console.log(d3.select('#slider3text').text());

    g.selectAll("circle")       
       .data(data)
	   .enter()
       .append("circle")
       .filter(function(d) { return d.mins == parseInt(d3.select('#slider3text').text())})
       .attr("cx", function(d) {
               return projection([d.lon, d.lat])[0];
       })
       .attr("cy", function(d) {
               return projection([d.lon, d.lat])[1];
       })
       .attr("r", 5)
       .style("fill", "crimson")
       .on("mouseover", showtooltip)
       .on("mouseout", hidetooltip)

});





}


$(document).ready(function(){


// load and display the World
d3.json("world-110m2.json", function(error, topology) {


displaydata();
// load and display the cities

g.selectAll("path")
      .data(topojson.object(topology, topology.objects.countries)
          .geometries)
    .enter()
      .append("path")
      .attr("d", path)
});

// var margin = {top: 20, right: 20, bottom: 30, left: 40},
//     width = 1200 - margin.left - margin.right,
//     height = 200 - margin.top - margin.bottom;

// var x = d3.scale.linear()
//     .range([0, width]);

// var y = d3.scale.linear()
//     .range([height-20, 0]);

// var color = d3.scale.category20();

// var xAxis = d3.svg.axis()
//     .scale(x)
//     .orient("bottom");

// var yAxis = d3.svg.axis()
//     .scale(y)
//     .orient("left");

// var svg = d3.select("body").append("svg")
//     .attr("width", width + margin.left + margin.right)
//     .attr("height", height + margin.top + margin.bottom)
//   	.append("g")
//     .attr("transform", "translate(" + margin.left + "," + margin.top + ")");



});